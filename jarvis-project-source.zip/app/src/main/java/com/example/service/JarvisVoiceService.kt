package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.JarvisDatabase
import com.example.data.model.CommandActionType
import com.example.data.repository.JarvisRepository
import com.example.data.repository.SettingsRepository
import com.example.state.JarvisStateHolder
import com.example.state.VoiceStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisVoiceService : Service(), TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var jarvisRepo: JarvisRepository

    private var isServiceRunning = false
    private var isSpeaking = false
    private var isAwaitingCommandFollowUp = false
    private var followUpTimeoutRunnable: Runnable? = null
    private var consecutiveErrorCount = 0

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository.getInstance(this)
        val database = JarvisDatabase.getDatabase(this)
        jarvisRepo = JarvisRepository(this, database.customCommandDao())

        createNotificationChannel()
        initTextToSpeech()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_STOP -> {
                stopVoiceService()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_SCHOOL_MODE -> {
                val currentSchoolMode = settingsRepo.isSchoolMode.value
                val newSchoolMode = !currentSchoolMode
                settingsRepo.setSchoolMode(newSchoolMode)
                if (newSchoolMode) {
                    JarvisStateHolder.updateStatus(VoiceStatus.SCHOOL_MODE)
                    JarvisStateHolder.addLog("School Mode activated. Microphone strictly stopped.", isSystem = true)
                    speakResponse("School Mode activated.") {
                        stopVoiceService()
                    }
                } else {
                    JarvisStateHolder.addLog("School Mode deactivated.", isSystem = true)
                    speakResponse("School Mode deactivated.")
                }
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (settingsRepo.isSchoolMode.value) {
                    JarvisStateHolder.updateStatus(VoiceStatus.SCHOOL_MODE)
                    JarvisStateHolder.addLog("Cannot start: School Mode is active.", isSystem = true)
                    stopSelf()
                    return START_NOT_STICKY
                }

                if (!hasAudioPermission()) {
                    JarvisStateHolder.updateStatus(VoiceStatus.DISABLED)
                    JarvisStateHolder.addLog("Microphone permission required to run JARVIS.", isSystem = true)
                    stopSelf()
                    return START_NOT_STICKY
                }

                startInForeground()
                isServiceRunning = true
                settingsRepo.setJarvisEnabled(true)
                consecutiveErrorCount = 0

                JarvisStateHolder.updateStatus(
                    if (settingsRepo.isWakeWordRequired.value) VoiceStatus.WAITING_FOR_WAKE_WORD
                    else VoiceStatus.LISTENING
                )
                JarvisStateHolder.addLog("JARVIS Voice Assistant online. Listening active.", isSystem = true)

                mainHandler.postDelayed({
                    initializeAndStartSpeechRecognizer()
                }, 300)

                return START_STICKY
            }
        }

        return START_STICKY
    }

    private fun startInForeground() {
        val notification = buildForegroundNotification("Online - Waiting for \"Jarvis\"")
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }

        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                foregroundType
            )
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback for older devices or restricted environments
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(this, this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.let { tts ->
                val selectedLang = settingsRepo.speechLanguage.value
                val locale = getLocaleForLanguage(selectedLang)
                val langResult = tts.setLanguage(locale)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.language = Locale.US
                }
                tts.setPitch(0.95f)
                tts.setSpeechRate(1.05f)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                        JarvisStateHolder.updateStatus(VoiceStatus.SPEAKING)
                    }

                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post {
                            if (isServiceRunning && !settingsRepo.isSchoolMode.value) {
                                JarvisStateHolder.updateStatus(
                                    if (isAwaitingCommandFollowUp) VoiceStatus.LISTENING
                                    else if (settingsRepo.isWakeWordRequired.value) VoiceStatus.WAITING_FOR_WAKE_WORD
                                    else VoiceStatus.LISTENING
                                )
                                restartListeningSafely(delayMs = 250)
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post {
                            if (isServiceRunning && !settingsRepo.isSchoolMode.value) {
                                restartListeningSafely(delayMs = 250)
                            }
                        }
                    }
                })
                isTtsReady = true
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun initializeAndStartSpeechRecognizer() {
        if (!isServiceRunning || settingsRepo.isSchoolMode.value || !hasAudioPermission()) {
            return
        }

        mainHandler.post {
            try {
                if (speechRecognizer != null) {
                    try {
                        speechRecognizer?.destroy()
                    } catch (e: Exception) {
                        // Safe destroy
                    }
                    speechRecognizer = null
                }

                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    JarvisStateHolder.addLog("Speech recognition is not available on this device.", isSystem = true)
                    JarvisStateHolder.updateStatus(VoiceStatus.DISABLED)
                    stopVoiceService()
                    return@post
                }

                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(JarvisRecognitionListener())
                }

                beginListeningIntent()
            } catch (e: Exception) {
                e.printStackTrace()
                JarvisStateHolder.addLog("Speech recognizer init error: ${e.localizedMessage}", isSystem = true)
                restartListeningSafely(delayMs = 2000)
            }
        }
    }

    private fun beginListeningIntent() {
        if (!isServiceRunning || settingsRepo.isSchoolMode.value || isSpeaking) {
            return
        }

        try {
            val lang = settingsRepo.speechLanguage.value
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            restartListeningSafely(delayMs = 1000)
        }
    }

    private fun restartListeningSafely(delayMs: Long = 300) {
        if (!isServiceRunning || settingsRepo.isSchoolMode.value) return

        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (isServiceRunning && !settingsRepo.isSchoolMode.value && !isSpeaking) {
                try {
                    beginListeningIntent()
                } catch (e: Exception) {
                    initializeAndStartSpeechRecognizer()
                }
            }
        }, delayMs)
    }

    private inner class JarvisRecognitionListener : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            consecutiveErrorCount = 0
            JarvisStateHolder.updateAmplitude(0f)
            if (!isSpeaking) {
                JarvisStateHolder.updateStatus(
                    if (isAwaitingCommandFollowUp) VoiceStatus.LISTENING
                    else if (settingsRepo.isWakeWordRequired.value) VoiceStatus.WAITING_FOR_WAKE_WORD
                    else VoiceStatus.LISTENING
                )
            }
        }

        override fun onBeginningOfSpeech() {
            JarvisStateHolder.updateStatus(VoiceStatus.LISTENING)
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (!isSpeaking) {
                JarvisStateHolder.updateAmplitude(rmsdB)
            }
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            JarvisStateHolder.updateAmplitude(0f)
            JarvisStateHolder.updateStatus(VoiceStatus.PROCESSING)
        }

        override fun onError(error: Int) {
            JarvisStateHolder.updateAmplitude(0f)

            if (!isServiceRunning || settingsRepo.isSchoolMode.value) return

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    // Normal idle timeout while waiting for wake word, quietly restart
                    restartListeningSafely(delayMs = 200)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> {
                    consecutiveErrorCount++
                    val backoff = if (consecutiveErrorCount > 5) 2000L else 500L
                    mainHandler.postDelayed({
                        initializeAndStartSpeechRecognizer()
                    }, backoff)
                }
                SpeechRecognizer.ERROR_AUDIO,
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    consecutiveErrorCount++
                    restartListeningSafely(delayMs = 1200)
                }
                else -> {
                    restartListeningSafely(delayMs = 500)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            JarvisStateHolder.updateAmplitude(0f)
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val recognizedText = matches?.firstOrNull()?.trim() ?: ""

            if (recognizedText.isNotBlank()) {
                JarvisStateHolder.setRecognizedPhrase(recognizedText)
                handleRecognizedSpeech(recognizedText)
            } else {
                restartListeningSafely(delayMs = 200)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val partialText = partialMatches?.firstOrNull()?.trim() ?: ""
            if (partialText.isNotBlank()) {
                // If wake word detected in partial stream, give instant visual feedback
                if (partialText.contains("jarvis", ignoreCase = true)) {
                    JarvisStateHolder.updateStatus(VoiceStatus.LISTENING)
                }
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleRecognizedSpeech(rawText: String) {
        val lowerText = rawText.lowercase(Locale.ROOT).trim()
        val wakeWordRequired = settingsRepo.isWakeWordRequired.value

        // Check wake word condition
        val hasWakeWord = lowerText.contains("jarvis")

        if (wakeWordRequired && !isAwaitingCommandFollowUp && !hasWakeWord) {
            // Wake word required but wasn't spoken; safely resume waiting
            restartListeningSafely(delayMs = 250)
            return
        }

        // Cancel any pending follow-up timeout
        cancelFollowUpTimeout()

        // Extract command text
        val command = if (hasWakeWord) {
            val parts = lowerText.split("jarvis", limit = 2)
            val after = parts.getOrNull(1)?.trim() ?: ""
            after.removePrefix(",").removePrefix(".").trim()
        } else {
            lowerText
        }

        // If user just said "Jarvis" without a command
        if (command.isBlank() && hasWakeWord) {
            isAwaitingCommandFollowUp = true
            JarvisStateHolder.updateStatus(VoiceStatus.LISTENING)
            speakResponse("Yes, sir?") {
                startFollowUpTimeout()
            }
            return
        }

        isAwaitingCommandFollowUp = false
        processParsedCommand(command)
    }

    private fun startFollowUpTimeout() {
        cancelFollowUpTimeout()
        followUpTimeoutRunnable = Runnable {
            if (isAwaitingCommandFollowUp) {
                isAwaitingCommandFollowUp = false
                JarvisStateHolder.updateStatus(VoiceStatus.WAITING_FOR_WAKE_WORD)
                restartListeningSafely(delayMs = 200)
            }
        }
        mainHandler.postDelayed(followUpTimeoutRunnable!!, 7000)
    }

    private fun cancelFollowUpTimeout() {
        followUpTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        followUpTimeoutRunnable = null
    }

    private fun processParsedCommand(command: String) {
        serviceScope.launch {
            JarvisStateHolder.updateStatus(VoiceStatus.PROCESSING)

            // 1. Built-in: School Mode commands
            if (command.contains("activate school mode") ||
                command.contains("enable school mode") ||
                command.contains("school mode on") ||
                command == "school mode"
            ) {
                settingsRepo.setSchoolMode(true)
                JarvisStateHolder.updateStatus(VoiceStatus.SCHOOL_MODE)
                JarvisStateHolder.setResponse("School Mode activated.")
                speakResponse("School Mode activated.") {
                    stopVoiceService()
                }
                return@launch
            }

            if (command.contains("deactivate school mode") ||
                command.contains("disable school mode") ||
                command.contains("school mode off")
            ) {
                settingsRepo.setSchoolMode(false)
                JarvisStateHolder.setResponse("School Mode deactivated.")
                speakResponse("School Mode deactivated.")
                return@launch
            }

            // 2. Built-in: Stop listening / Shutdown
            if (command.contains("stop listening") ||
                command.contains("turn off jarvis") ||
                command.contains("deactivate jarvis") ||
                command.contains("shutdown") ||
                command == "stop"
            ) {
                settingsRepo.setJarvisEnabled(false)
                JarvisStateHolder.setResponse("Deactivating voice assistant.")
                speakResponse("Deactivating voice assistant.") {
                    stopVoiceService()
                }
                return@launch
            }

            // 3. Built-in: Go Home
            if (command.contains("go home") ||
                command.contains("home screen") ||
                command == "home"
            ) {
                launchHomeScreen()
                JarvisStateHolder.setResponse("Going home.")
                speakResponse("Going home.")
                return@launch
            }

            // 4. Custom Commands from local Room Database
            val customCommands = jarvisRepo.getEnabledCommandsList()
            val matchedCustom = customCommands.firstOrNull { cmd ->
                val cleanTrigger = cmd.triggerPhrase.lowercase().trim()
                command.contains(cleanTrigger) || cleanTrigger.contains(command)
            }

            if (matchedCustom != null) {
                executeCustomCommand(matchedCustom)
                return@launch
            }

            // 5. Built-in: App Launching ("open [app]", "launch [app]", "start [app]")
            val appQuery = extractAppQuery(command)
            if (appQuery.isNotBlank()) {
                val foundApp = jarvisRepo.findAppByName(appQuery)
                if (foundApp != null) {
                    val launched = launchAppByPackage(foundApp.packageName)
                    if (launched) {
                        val response = "Opening ${foundApp.label}."
                        JarvisStateHolder.setResponse(response)
                        speakResponse(response)
                    } else {
                        val response = "I couldn't find that app."
                        JarvisStateHolder.setResponse(response)
                        speakResponse(response)
                    }
                } else {
                    val response = "I couldn't find that app."
                    JarvisStateHolder.setResponse(response)
                    speakResponse(response)
                }
                return@launch
            }

            // 6. Time inquiry helper
            if (command.contains("what time is it") || command.contains("current time") || command == "time") {
                val timeStr = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                val response = "The time is $timeStr."
                JarvisStateHolder.setResponse(response)
                speakResponse(response)
                return@launch
            }

            // Unknown command fallback
            val fallbackResponse = "I couldn't understand that command."
            JarvisStateHolder.setResponse(fallbackResponse)
            speakResponse(fallbackResponse)
        }
    }

    private fun extractAppQuery(command: String): String {
        val prefixes = listOf("open", "launch", "start", "run", "play")
        for (prefix in prefixes) {
            if (command.startsWith("$prefix ")) {
                return command.substring(prefix.length + 1).trim()
            }
        }
        return ""
    }

    private fun executeCustomCommand(command: com.example.data.model.CustomCommand) {
        when (command.actionType) {
            CommandActionType.OPEN_APP.name -> {
                val pkg = command.targetPackage
                if (!pkg.isNullOrBlank()) {
                    val launched = launchAppByPackage(pkg)
                    val response = command.responseText ?: if (launched) "Opening ${command.targetAppName ?: "app"}." else "I couldn't find that app."
                    JarvisStateHolder.setResponse(response)
                    speakResponse(response)
                } else {
                    val response = command.responseText ?: "Target app not specified."
                    JarvisStateHolder.setResponse(response)
                    speakResponse(response)
                }
            }
            CommandActionType.GO_HOME.name -> {
                launchHomeScreen()
                val response = command.responseText ?: "Going home."
                JarvisStateHolder.setResponse(response)
                speakResponse(response)
            }
            CommandActionType.ACTIVATE_SCHOOL_MODE.name -> {
                settingsRepo.setSchoolMode(true)
                val response = command.responseText ?: "School Mode activated."
                JarvisStateHolder.setResponse(response)
                speakResponse(response) {
                    stopVoiceService()
                }
            }
            CommandActionType.DEACTIVATE_SCHOOL_MODE.name -> {
                settingsRepo.setSchoolMode(false)
                val response = command.responseText ?: "School Mode deactivated."
                JarvisStateHolder.setResponse(response)
                speakResponse(response)
            }
            CommandActionType.SPEAK_TEXT.name -> {
                val response = command.responseText ?: "Command executed."
                JarvisStateHolder.setResponse(response)
                speakResponse(response)
            }
            else -> {
                speakResponse("Command executed.")
            }
        }
    }

    private fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun launchHomeScreen() {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun speakResponse(text: String, onFinished: (() -> Unit)? = null) {
        val voiceResponseEnabled = settingsRepo.isVoiceResponseEnabled.value

        if (!voiceResponseEnabled || !isTtsReady || textToSpeech == null) {
            onFinished?.invoke()
            if (isServiceRunning && !settingsRepo.isSchoolMode.value) {
                restartListeningSafely(delayMs = 400)
            }
            return
        }

        try {
            // Stop speech recognizer so JARVIS doesn't listen to its own voice
            speechRecognizer?.stopListening()
            isSpeaking = true
            JarvisStateHolder.updateStatus(VoiceStatus.SPEAKING)

            val utteranceId = "jarvis_tts_${System.currentTimeMillis()}"
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)

            // If onFinished callback provided, post with estimated duration fallback
            if (onFinished != null) {
                val estimatedDurationMs = ((text.length * 75L) + 500L).coerceAtLeast(1000L)
                mainHandler.postDelayed({
                    onFinished.invoke()
                }, estimatedDurationMs)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            isSpeaking = false
            onFinished?.invoke()
            restartListeningSafely(delayMs = 400)
        }
    }

    private fun stopVoiceService() {
        isServiceRunning = false
        settingsRepo.setJarvisEnabled(false)
        JarvisStateHolder.updateStatus(
            if (settingsRepo.isSchoolMode.value) VoiceStatus.SCHOOL_MODE else VoiceStatus.DISABLED
        )
        JarvisStateHolder.updateAmplitude(0f)
        cancelFollowUpTimeout()
        mainHandler.removeCallbacksAndMessages(null)

        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            // Safe cleanup
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        cancelFollowUpTimeout()
        mainHandler.removeCallbacksAndMessages(null)
        serviceScope.cancel()

        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            // Safe cleanup
        }

        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            // Safe cleanup
        }

        JarvisStateHolder.updateAmplitude(0f)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground voice listening and wake word detection"
                setShowBadge(false)
                enableVibration(false)
                enableLights(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, JarvisVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val schoolModeIntent = Intent(this, JarvisVoiceService::class.java).apply {
            action = ACTION_TOGGLE_SCHOOL_MODE
        }
        val pendingSchoolMode = PendingIntent.getService(
            this,
            2,
            schoolModeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS AI Assistant")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpenApp)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Turn OFF", pendingStop)
            .addAction(android.R.drawable.ic_lock_idle_lock, "School Mode", pendingSchoolMode)
            .build()
    }

    private fun getLocaleForLanguage(code: String): Locale {
        return when (code) {
            "en-US" -> Locale.US
            "en-GB" -> Locale.UK
            "es-ES" -> Locale("es", "ES")
            "de-DE" -> Locale.GERMANY
            "fr-FR" -> Locale.FRANCE
            "it-IT" -> Locale.ITALY
            "ja-JP" -> Locale.JAPAN
            "hi-IN" -> Locale("hi", "IN")
            else -> Locale.getDefault()
        }
    }

    companion object {
        const val CHANNEL_ID = "jarvis_voice_service_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.jarvis.START"
        const val ACTION_STOP = "com.example.jarvis.STOP"
        const val ACTION_TOGGLE_SCHOOL_MODE = "com.example.jarvis.TOGGLE_SCHOOL_MODE"

        fun startService(context: Context) {
            val intent = Intent(context, JarvisVoiceService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, JarvisVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun toggleSchoolMode(context: Context) {
            val intent = Intent(context, JarvisVoiceService::class.java).apply {
                action = ACTION_TOGGLE_SCHOOL_MODE
            }
            context.startService(intent)
        }
    }
}
