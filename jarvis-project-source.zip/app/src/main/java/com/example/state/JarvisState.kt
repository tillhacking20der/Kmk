package com.example.state

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VoiceStatus(val label: String, val subtitle: String) {
    DISABLED("Disabled", "Tap power button to activate JARVIS"),
    SCHOOL_MODE("School Mode Active", "Voice recognition & microphone strictly disabled"),
    WAITING_FOR_WAKE_WORD("Waiting for \"Jarvis\"", "Say \"Jarvis\" followed by your command"),
    LISTENING("Listening...", "Say your command now"),
    PROCESSING("Processing...", "Interpreting voice command"),
    SPEAKING("Responding...", "Speaking response via Text-to-Speech")
}

data class JarvisLogEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: Long = System.currentTimeMillis(),
    val message: String,
    val isCommand: Boolean = false,
    val isSystem: Boolean = false
)

object JarvisStateHolder {
    private val _voiceStatus = MutableStateFlow(VoiceStatus.DISABLED)
    val voiceStatus: StateFlow<VoiceStatus> = _voiceStatus.asStateFlow()

    private val _soundAmplitude = MutableStateFlow(0f)
    val soundAmplitude: StateFlow<Float> = _soundAmplitude.asStateFlow()

    private val _lastRecognizedPhrase = MutableStateFlow("")
    val lastRecognizedPhrase: StateFlow<String> = _lastRecognizedPhrase.asStateFlow()

    private val _lastResponse = MutableStateFlow("")
    val lastResponse: StateFlow<String> = _lastResponse.asStateFlow()

    private val _recentLogs = MutableStateFlow<List<JarvisLogEntry>>(
        listOf(
            JarvisLogEntry(
                message = "JARVIS Core Initialized. Systems nominal.",
                isSystem = true
            )
        )
    )
    val recentLogs: StateFlow<List<JarvisLogEntry>> = _recentLogs.asStateFlow()

    fun updateStatus(status: VoiceStatus) {
        _voiceStatus.value = status
    }

    fun updateAmplitude(rmsLevel: Float) {
        // Normalize RMS dB (-2 to 10 typical in Android speech recognition) to 0f..1f
        val normalized = ((rmsLevel + 2f) / 12f).coerceIn(0f, 1f)
        _soundAmplitude.value = normalized
    }

    fun setRecognizedPhrase(phrase: String) {
        _lastRecognizedPhrase.value = phrase
        if (phrase.isNotBlank()) {
            addLog("Heard: \"$phrase\"", isCommand = true)
        }
    }

    fun setResponse(response: String) {
        _lastResponse.value = response
        if (response.isNotBlank()) {
            addLog("JARVIS: \"$response\"", isSystem = true)
        }
    }

    fun addLog(message: String, isCommand: Boolean = false, isSystem: Boolean = false) {
        val entry = JarvisLogEntry(message = message, isCommand = isCommand, isSystem = isSystem)
        val currentList = _recentLogs.value.toMutableList()
        currentList.add(0, entry)
        // Keep max 30 recent logs
        if (currentList.size > 30) {
            currentList.removeAt(currentList.lastIndex)
        }
        _recentLogs.value = currentList
    }

    fun clearLogs() {
        _recentLogs.value = listOf(
            JarvisLogEntry(message = "Telemetry logs cleared.", isSystem = true)
        )
    }
}
